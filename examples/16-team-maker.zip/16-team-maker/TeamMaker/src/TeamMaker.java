import java.util.ArrayList;
import java.util.Random;


public class TeamMaker {
	
    public static void main(String[] arguments)
    {
        Settings settings = new Settings();
        ArrayList<String> playersList = new ArrayList<String>();
        playersList.add("Lazar Sestrimski");
        playersList.add("Ivan Ivanov");
        playersList.add("Georgi Georgiev");
        playersList.add("Peter Petrov");
        playersList.add("Hristo Hristov");
        playersList.add("Dimitar Dimitrov");
        playersList.add("Kiril Kirilov");
        
        settings.setPlayersList(playersList);
        settings.setNumberOfTeams(2);
        
        Random rand  = new Random();
        ArrayList<ArrayList<String>> teams = new ArrayList<ArrayList<String>>();
        int originalPlayersCount = settings.getPlayersList().size();
        for (int i = 0; i < settings.getNumberOfTeams(); i++)
        {
            teams.add(new ArrayList<String>());
        }

        while (settings.getPlayersList().size() != 0)
        {
            int playerIdx = rand.nextInt(settings.getPlayersList().size());
            int teamIdx = rand.nextInt(settings.getNumberOfTeams());
            if (teams.get(teamIdx).size() == originalPlayersCount/settings.getNumberOfTeams())
            {
                continue;
            }
            teams.get(teamIdx).add(settings.getPlayersList().get(playerIdx));
            settings.getPlayersList().remove(playerIdx);
        }

        PrintTeams(teams);
    }
	
	
    public static void PrintTeams(ArrayList<ArrayList<String>> teams)
    {
        for (int i = 0; i < teams.size(); i++)
        {
            System.out.println("Team: "+(i + 1));
            for (int j = 0; j < teams.get(i).size(); j++)
            {
            	System.out.println("\t" + teams.get(i).get(j));
            }
        }
    }
}
